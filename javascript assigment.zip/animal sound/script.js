
// sheep audio
document.getElementById('sheep').addEventListener('click',function (e) {
    e.preventDefault();
    document.getElementById('audio').play();
});


// cow audio
document.getElementById('cow').addEventListener('click',function (e) {
    e.preventDefault();
    document.getElementById('cow_audio').play();
});

// duck audio
document.getElementById('duck').addEventListener('click',function (e) {
    e.preventDefault();
    document.getElementById('duck_audio').play();
});

// lion audio
document.getElementById('lion').addEventListener('click',function (e) {
    e.preventDefault();
    document.getElementById('lion_audio').play();
});